<!DOCTYPE html>
<html>
<body>

<?php
echo "Today is " . date("Y/m/d") . "<br>";
echo "Date (1449334800) is " . date("Y.m.d",1449334800) . "<br>";

?>

</body>
</html>